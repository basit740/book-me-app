import React from 'react'

const Layout = ({children}:any) => {
  return (
    <React.Fragment>
        {children}
    </React.Fragment>
  )
}

export default Layout