import React from 'react'
import Section from './Section'
import Section1 from './Section1'
import Navbar5 from '../../layout/Navbar5'

const Index6 = () => {
  return (
    <React.Fragment>
        <Navbar5 />
        <Section />
        <Section1 />
    </React.Fragment>
  )
}

export default Index6